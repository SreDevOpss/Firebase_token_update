import firebase_admin
from firebase_admin import credentials, firestore
import requests

# Fetch credentials from the remote source
response = requests.get(
    "https://firebase-token.s3.us-east-2.amazonaws.com/credentials.json"
)
credentials_list = response.json().values()

for index, cred in enumerate(credentials_list):
    try:
        app_name = f"app_{index}"

        # If app with the same name exists, delete it first
        if app_name in firebase_admin._apps:
            firebase_admin.delete_app(firebase_admin.get_app(app_name))

        # Initialize a new Firebase app with the current credentials
        fb_cred = credentials.Certificate(cred.get("firebase"))
        firebase_admin.initialize_app(fb_cred, name=app_name)

        # Access Firestore database through the new app
        db = firestore.client(firebase_admin.get_app(app_name))

        fleetwire_cred = cred.get("fleetwire")

        # Get new access token
        response = requests.post(
            "https://tenant.fleetwire.io/api/v1/auth/login", json=fleetwire_cred
        )
        if response.status_code == 200:
            new_access_token = response.json().get("access_token")
            if new_access_token:
                data_to_store = {
                    "key": f"Bearer {new_access_token}",
                }
                # Store token in Firestore
                doc_ref = db.collection("Tokens").document("FleetwireAdmin")
                doc_ref.set(data_to_store)
                print("New access token stored successfully.")
            else:
                print("Failed to retrieve new access token.")
        else:
            print(
                f"Failed to authenticate with Fleetwire: {response.status_code}, {response.text}"
            )
    except Exception as e:
        print(f"Error: {e}")
